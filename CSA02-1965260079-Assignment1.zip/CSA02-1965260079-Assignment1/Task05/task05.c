/* Task 05: include guard and compile-time DEBUG flag. */
#include <stdio.h>
#include "billing.h"
long simple_bill_paise(int units) {
    long total = FIXED_CHARGE_PAISE + (long)(units > 100 ? units-100 : 0) * RATE2_PAISE;
#ifdef DEBUG
    fprintf(stderr, "DEBUG units=%d total_paise=%ld\n", units, total);
#endif
    return total;
}
int main(void) {
    int units=150;
    long p=simple_bill_paise(units);
    printf("%d units -> Rs %ld.%02ld\n", units, p/100, p%100);
    return 0;
}
