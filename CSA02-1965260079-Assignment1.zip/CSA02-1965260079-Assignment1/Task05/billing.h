#ifndef BILLING_H
#define BILLING_H
#define RATE2_PAISE 225L
#define FIXED_CHARGE_PAISE 5000L
long simple_bill_paise(int units);
#endif
