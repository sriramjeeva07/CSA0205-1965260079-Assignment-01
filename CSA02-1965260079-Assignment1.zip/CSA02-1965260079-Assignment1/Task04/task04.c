/* Task 04: safe macros, pitfalls and inline alternatives. */
#include <stdio.h>
#define RUPEES_TO_PAISE(r) ((long)(r) * 100L)
#define SQUARE(x) ((x) * (x))
#define MAX_MACRO(a,b) ((a) > (b) ? (a) : (b))
static inline long square_long(long x) { return x*x; }
static inline int max_int(int a, int b) { return a > b ? a : b; }
int main(void) {
    int a=3, i=4, j=7;
    printf("SQUARE(a+1)=%d (expected 16)\n", SQUARE(a+1));
    printf("inline square=%ld\n", square_long(a+1));
    printf("MAX_MACRO(4,7)=%d; inline max=%d\n", MAX_MACRO(4,7), max_int(4,7));
    printf("100 rupees = %ld paise\n", RUPEES_TO_PAISE(100));
    /* Do not call MAX_MACRO(i++, j): macro may evaluate i++ more than once. */
    printf("side-effect caution example: i=%d j=%d (avoid side effects in macro args)\n", i, j);
    return 0;
}
