/* Task 11: final recommended design summary. */
#include <stdio.h>
#include <limits.h>
int main(void) {
    printf("Meter reading: unsigned short only when hardware range is known (0..65535).\n");
    printf("Consumption: unsigned int / unsigned long with explicit rollover validation.\n");
    printf("Money per bill: long long integer paise; aggregate totals: long long with bound checks.\n");
    printf("Tariff: named constants for fixed rules; configuration file for frequently revised rates.\n");
    printf("District test: 800000 * Rs 950.00 = Rs 760000000.00; paise total = 76000000000.\n");
    printf("LLONG_MAX=%lld; never cast large totals to int.\n", LLONG_MAX);
    return 0;
}
