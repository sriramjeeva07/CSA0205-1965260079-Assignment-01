/* Task 06: checked formatted input and paise output. */
#include <stdio.h>
int main(void) {
    int units;
    if (scanf("%d", &units) != 1) {
        fprintf(stderr, "Invalid input: enter a whole-number unit count.\n");
        return 1;
    }
    if (units < 0) {
        fprintf(stderr, "Invalid input: units cannot be negative.\n");
        return 1;
    }
    long bill_paise = 5000L + (units > 100 ? (long)(units-100)*225L : 0L);
    printf("Units: %d\nBill: Rs %ld.%02ld\n", units, bill_paise/100, bill_paise%100);
    return 0;
}
