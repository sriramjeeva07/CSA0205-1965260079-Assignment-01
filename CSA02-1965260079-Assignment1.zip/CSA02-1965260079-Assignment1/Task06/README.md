# Task06

**Purpose:** Task06 component of the C Programming Assignment 1.

## Compile

```sh
gcc -std=c11 -Wall -Wextra -pedantic task06.c -o program
```

Task05 also needs `billing.h` in the same directory; use `-DDEBUG` to enable debug output. Task12 needs `config.txt` in the working directory.

## Run

```sh
./program
```

See `evidence/` for captured run output.
