# C Programming Assignment 1 — Grama Jyothi Billing System

**Student name:** S.Jeevan  
**Register number:** 1965260079  
**Compiler used for prepared evidence:** GCC 14.2.0 (Linux environment)  
**Language:** C11  

## Assignment structure

- `Task01/` through `Task12/`: individual source code, local instructions, and captured output evidence.
- `Assignment_Report.docx` and `Assignment_Report.pdf`: report for all 12 tasks.
- `config.txt` inside Task12 controls the smart-meter tariff without recompiling.

## Compile and run

Example (from a task folder):
```sh
gcc -std=c11 -Wall -Wextra -pedantic task02.c -o program
./program
```
For Task05 debug output: `gcc -std=c11 -Wall -Wextra -pedantic -DDEBUG task05.c -o program`.  
Task06 expects one integer on standard input. Task09 asks for previous and current meter readings. Task12 reads tariff settings from `config.txt` and asks for off-peak and peak watt-hours.

## Tariff assumptions

- Fixed charge: Rs 50.00.
- First 100 units: Rs 0.00/unit.
- Units 101–200: Rs 2.25/unit.
- Units above 200: Rs 4.50/unit.
- Task09 treats a decrease as rollover only when the previous reading is at least 60000 and the current reading is at most 1000. This explicit plausibility rule is used to distinguish a rollover from a likely data-entry error. The threshold is an engineering assumption, not a fact supplied by the meter hardware.
- Task12 config format: `base_rate_paise_per_kwh fixed_charge_paise peak_extra_percent`. Example: `225 5000 20`. Peak window is 18:00–22:00; this sample program accepts already-separated peak/off-peak watt-hour totals. A production system should classify timestamps per interval and use checked arithmetic for all intermediate products.

## Evidence notes

The `evidence/` files are captured outputs from programs executed in the preparation environment. They are not screenshots from your personal computer. For your submission, run each program on your own system and capture your own screenshots if your instructor expects local screenshots. Update the compiler/version if your local setup differs before submitting.

## Progressive Git commits

After creating the repository, make an initial commit and then one commit per task, for example:
```sh
git add README.md && git commit -m "Add assignment overview"
for n in $(seq -w 1 12); do git add Task$n; git commit -m "Complete Task$n"; done
git add Assignment_Report.docx Assignment_Report.pdf && git commit -m "Add assignment report"
```
If your shell does not preserve `Task01` naming with `seq -w`, commit folders individually. Review all code and make sure you can explain it in the viva before submitting.
