/* Task 08: simple compilation-pipeline specimen. */
#include <stdio.h>
#define MESSAGE "Compilation stages: preprocess, compile, assemble, link, run"
int main(void) { puts(MESSAGE); return 0; }
