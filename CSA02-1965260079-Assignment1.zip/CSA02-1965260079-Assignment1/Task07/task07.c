/* Task 07: type conversion and precision demonstrations. */
#include <stdio.h>
#include <limits.h>
int main(void) {
    printf("5/2 integer division = %d\n", 5/2);
    printf("5/2.0 floating division = %.2f\n", 5/2.0);
    printf("(int)3.99 = %d\n", (int)3.99);
    float f=0.1f+0.2f;
    printf("0.1f + 0.2f = %.9f (not exactly 0.3)\n", f);
    long big=(long)INT_MAX+100L;
    printf("long value above INT_MAX = %ld\n", big);
    printf("Cast to int may be implementation-defined when out of range; avoid it.\n");
    return 0;
}
