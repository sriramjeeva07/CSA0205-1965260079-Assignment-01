/* Task 10: compare float and exact integer-paise accumulation. */
#include <stdio.h>
int main(void) {
    const int counts[]={4000,60000,800000};
    const float sample_rupees=162.50f;
    const long long sample_paise=16250LL;
    for (size_t i=0;i<sizeof counts/sizeof counts[0];++i) {
        int n=counts[i]; float ftotal=0.0f; long long ptotal=0;
        for (int j=0;j<n;++j) { ftotal += sample_rupees; ptotal += sample_paise; }
        printf("n=%d float_total=%.2f exact_total=%.2f difference=%.2f\n", n, ftotal, ptotal/100.0, ftotal-ptotal/100.0);
    }
    printf("District-scale exact total uses long long; check overflow bounds for production tariffs.\n");
    return 0;
}
