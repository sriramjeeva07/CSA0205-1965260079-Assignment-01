/* Task 09: complete validated billing program. */
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define METER_MAX 65535UL
#define FIXED_PAISE 5000LL
#define RATE2_PAISE 225LL
#define RATE3_PAISE 450LL
#define ROLLOVER_PREV_MIN 60000UL
#define ROLLOVER_CURR_MAX 1000UL
static int parse_reading(const char *prompt, unsigned long *out) {
    char buf[128], extra;
    printf("%s", prompt);
    if (!fgets(buf, sizeof buf, stdin)) return 0;
    if (sscanf(buf, "%lu %c", out, &extra) != 1 || *out > METER_MAX) return 0;
    return 1;
}
static unsigned long consumption(unsigned long prev, unsigned long curr, int *ok) {
    if (curr >= prev) { *ok=1; return curr-prev; }
    if (prev >= ROLLOVER_PREV_MIN && curr <= ROLLOVER_CURR_MAX) {
        *ok=1; return (METER_MAX+1UL-prev)+curr;
    }
    *ok=0; return 0;
}
static long long bill_paise(unsigned long units) {
    unsigned long s2 = units > 100 ? (units < 200 ? units-100 : 100) : 0;
    unsigned long s3 = units > 200 ? units-200 : 0;
    return FIXED_PAISE + (long long)s2*RATE2_PAISE + (long long)s3*RATE3_PAISE;
}
int main(void) {
    unsigned long prev, curr; int ok;
    if (!parse_reading("Previous meter reading (0-65535): ", &prev) ||
        !parse_reading("Current meter reading (0-65535): ", &curr)) {
        fprintf(stderr,"Invalid input: enter integer readings from 0 to 65535.\n"); return 1;
    }
    unsigned long units=consumption(prev,curr,&ok);
    if (!ok) { fprintf(stderr,"Invalid reading decrease: not a plausible rollover.\n"); return 1; }
    long long p=bill_paise(units);
    printf("Units consumed: %lu\nEnergy charge: Rs %lld.%02lld\nFixed charge: Rs 50.00\nTotal bill: Rs %lld.%02lld\n",
      units, (p-FIXED_PAISE)/100, (p-FIXED_PAISE)%100, p/100, p%100);
    return 0;
}
