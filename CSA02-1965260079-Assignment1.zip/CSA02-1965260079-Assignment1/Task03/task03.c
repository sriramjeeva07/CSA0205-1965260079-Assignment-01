/* Task 03: centralized tariff constants and paise arithmetic. */
#include <stdio.h>
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE1_PAISE 0
#define RATE2_PAISE 225
#define RATE3_PAISE 450
#define FIXED_CHARGE_PAISE 5000L
long compute_bill(int units) {
    if (units < 0) return -1L;
    long paise = FIXED_CHARGE_PAISE;
    int slab2 = units > SLAB1_UNITS ? (units < SLAB2_UNITS ? units-SLAB1_UNITS : SLAB2_UNITS-SLAB1_UNITS) : 0;
    int slab3 = units > SLAB2_UNITS ? units-SLAB2_UNITS : 0;
    int slab1 = units < SLAB1_UNITS ? units : SLAB1_UNITS;
    paise += (long)slab1 * RATE1_PAISE;
    paise += (long)slab2 * RATE2_PAISE;
    paise += (long)slab3 * RATE3_PAISE;
    return paise;
}
int main(void) {
    int tests[] = {0,100,150,200,350};
    for (size_t i=0; i<sizeof tests/sizeof tests[0]; ++i) {
        long p=compute_bill(tests[i]);
        printf("%3d units -> Rs %ld.%02ld\n", tests[i], p/100, p%100);
    }
    return 0;
}
