/* Task 01: identify inputs/outputs and demonstrate text-reading conversion. */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>

int parse_reading(const char *text, unsigned long *value) {
    char *end = NULL;
    errno = 0;
    unsigned long v = strtoul(text, &end, 10);
    if (errno || end == text || *end != '\0' || v > 65535UL) return 0;
    *value = v;
    return 1;
}
int main(void) {
    const char *previous_text = "01530";
    unsigned long previous;
    if (!parse_reading(previous_text, &previous)) return 1;
    printf("Text reading %s converts to %lu\n", previous_text, previous);
    printf("Inputs: previous/current reading, household ID, category\n");
    printf("Outputs: units, energy charge, fixed charge, total bill\n");
    printf("Rule: total = fixed charge + energy charge; bill must be non-negative.\n");
    return 0;
}
