/* Task 02: rollover-safe consumption and type-size evidence. */
#include <stdio.h>
#include <limits.h>
#include <float.h>
typedef unsigned short meter_t;
unsigned int consumption(meter_t previous, meter_t current) {
    /* Conversion back to meter_t applies modulo 2^16 without if/else. */
    return (meter_t)(current - previous);
}
int main(void) {
    printf("sizeof(meter_t) = %zu bytes, maximum reading = %u\n", sizeof(meter_t), (unsigned)USHRT_MAX);
    printf("Consumption: %u units\n", consumption(1200, 1530));
    printf("Consumption: %u units\n", consumption(65400, 120));
    printf("sizeof(int)=%zu, INT_MAX=%d; sizeof(long long)=%zu, LLONG_MAX=%lld\n", sizeof(int), INT_MAX, sizeof(long long), LLONG_MAX);
    printf("FLT_DIG=%d, DBL_DIG=%d\n", FLT_DIG, DBL_DIG);
    return 0;
}
