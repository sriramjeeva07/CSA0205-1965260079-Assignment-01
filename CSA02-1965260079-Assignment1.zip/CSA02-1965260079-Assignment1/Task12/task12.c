/* Task 12: smart-meter design with configurable tariff and peak-hour uplift.
   config.txt format: base_rate_paise_per_kwh fixed_charge_paise peak_extra_percent
*/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define CONFIG_FILE "config.txt"
static int load_config(long long *rate, long long *fixed, long long *extra) {
    FILE *f=fopen(CONFIG_FILE,"r"); if(!f) return 0;
    int ok=fscanf(f,"%lld %lld %lld",rate,fixed,extra)==3; fclose(f);
    return ok && *rate>=0 && *fixed>=0 && *extra>=0 && *extra<=1000;
}
int main(void) {
    long long rate,fixed,extra;
    if(!load_config(&rate,&fixed,&extra)) {
        fprintf(stderr,"Cannot read config.txt (rate fixed_charge peak_extra_percent).\n"); return 1;
    }
    long long offpeak_wh, peak_wh;
    printf("Enter off-peak watt-hours then peak (18:00-22:00) watt-hours: ");
    if(scanf("%lld %lld",&offpeak_wh,&peak_wh)!=2 || offpeak_wh<0 || peak_wh<0) {
        fprintf(stderr,"Invalid watt-hour totals.\n"); return 1;
    }
    /* Check bounds BEFORE multiplication. Keep each product below half the range
       so their sum and the rounding offset remain representable. */
    if (rate > LLONG_MAX / (100LL + extra) || rate > LLONG_MAX / 100LL) {
        fprintf(stderr,"Tariff too large for 64-bit intermediate.\n"); return 1;
    }
    long long off_factor = rate * 100LL;
    long long peak_factor = rate * (100LL + extra);
    if ((off_factor > 0 && offpeak_wh > (LLONG_MAX / 2LL) / off_factor) ||
        (peak_factor > 0 && peak_wh > (LLONG_MAX / 2LL) / peak_factor)) {
        fprintf(stderr,"Input too large for 64-bit intermediate.\n"); return 1;
    }
    long long numerator = offpeak_wh * off_factor + peak_wh * peak_factor;
    if (numerator > LLONG_MAX - 50000LL) {
        fprintf(stderr,"Rounding addition would overflow.\n"); return 1;
    }
    long long energy_paise=(numerator+50000LL)/100000LL;
    if (fixed > LLONG_MAX - energy_paise) {
        fprintf(stderr,"Total bill would overflow.\n"); return 1;
    }
    long long total=fixed+energy_paise;
    printf("Off-peak: %lld Wh, peak: %lld Wh\n",offpeak_wh,peak_wh);
    printf("Energy charge: Rs %lld.%02lld\n",energy_paise/100,energy_paise%100);
    printf("Fixed charge: Rs %lld.%02lld\n",fixed/100,fixed%100);
    printf("Total: Rs %lld.%02lld\n",total/100,total%100);
    return 0;
}
